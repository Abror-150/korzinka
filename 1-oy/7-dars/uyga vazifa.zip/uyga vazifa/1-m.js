let count = 5

for(let i=0 ; i<=5;i++){
    console.log("*".repeat(i));

}