let start = 1
let end= 10
let s = 0
for(start; start<=end;start++){
    if(start % 2 !=0){
        s +=start

    }

}
console.log(s);