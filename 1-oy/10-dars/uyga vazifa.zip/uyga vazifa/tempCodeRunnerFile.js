if (i < words.length - 1) {
        //     result += " ";
        // }