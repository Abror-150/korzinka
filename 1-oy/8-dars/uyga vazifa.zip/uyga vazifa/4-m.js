
function ielts(listening, speaking,reading,writing){
    return ((listening+speaking+reading+writing)/4).toFixed(2)

}
console.log(ielts(8,7.5,7,6));


