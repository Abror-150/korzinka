
function ielts(ball){
    
    
    if (ball > 9) {
      console.log("Bunaqa ball yo'q");
    } else if (ball >= 8.5 && ball<9) {
      console.log("supergrant");
    } else if (ball >= 7.5 && ball<8.5) {
      console.log("Grant");
    } else if (ball >= 6.5 && ball<7.5) {
      console.log("kontrakt");
    } else if (ball >= 5.5 && ball<6.5) {
      console.log("Superkontrakt");
    } else if(ball < 5.5 && ball<6.5){
      console.log("Bro yaxshilab o'qigin")
    }
}

ielts(8)

    

   
    
